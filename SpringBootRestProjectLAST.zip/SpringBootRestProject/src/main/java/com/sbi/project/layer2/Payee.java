package com.sbi.project.layer2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component 
@Entity 
@Table(name="payee_tbl")
//@NamedQuery(name = "allPayeeOfApplicant", query = "select e from Payee e where e.appid >=:appid")
public class Payee {

	@Id
	@Column(name="payee_id")
	private int payeeid;
	
	@Column(name="payee_name")
	private String payeename;
	
	@Column(name="payee_acc")
	private String payeeacc;
	
	@Column(name="payee_ifsc")
	private String payeeifsc;

	@ManyToOne
	@JoinColumn(name="app_id")
	private Applicant appid;
	
	public int getPayeeid() {
		return payeeid;
	}

	public void setPayeeid(int payeeid) {
		this.payeeid = payeeid;
	}

	public String getPayeename() {
		return payeename;
	}

	public void setPayeename(String payeename) {
		this.payeename = payeename;
	}

	public String getPayeeacc() {
		return payeeacc;
	}

	public void setPayeeacc(String payeeacc) {
		this.payeeacc = payeeacc;
	}

	public String getPayeeifsc() {
		return payeeifsc;
	}

	public void setPayeeifsc(String payeeifsc) {
		this.payeeifsc = payeeifsc;
	}
	
	
}
