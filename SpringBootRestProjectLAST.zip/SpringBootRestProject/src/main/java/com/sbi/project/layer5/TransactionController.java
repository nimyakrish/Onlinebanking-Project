package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer4.TransactionService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/txns")
public class TransactionController {
	@Autowired
	TransactionService txnser;

	@RequestMapping("/getAll/{accNo}")
	public List<Transaction> getAllTxnsofAcc(@PathVariable("accNo") int searchAcc )
	{		
			return txnser.getAllTxnsofAcc(searchAcc,100);
		
	}
	@RequestMapping("/getMini/{accNo}")
	public List<Transaction> getTenTxnsofAcc(@PathVariable("accNo") int searchAcc )
	{		
			return txnser.getAllTxnsofAcc(searchAcc,10);
		
	}
	
}
