package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Payee;
import com.sbi.project.layer3.PayeeRepository;

@Service
public class PayeeServiceImpl implements PayeeService {

	@Autowired
	PayeeRepository ap;
	
	
	@Override
	public void createP(Payee pa) {
		// TODO Auto-generated method stub
		ap.createP(pa); 
	}

	@Override
	public void modifyP(Payee pa) {
		// TODO Auto-generated method stub
		ap.modifyP(pa);
	}

	@Override
	public boolean removeP(int pa) {
		// TODO Auto-generated method stub
		return ap.removeP(pa);
	}

	@Override
	public void findP(int pa) {
		// TODO Auto-generated method stub
		ap.findP(pa);	
		
	}

	@Override
	public List<Payee> findAllP() {
		// TODO Auto-generated method stub
		return ap.findAllP();
	
	}
	
	public List<Payee> getPayeeForApplicantService(int appid){
		return ap.getPayeeForApplicantRepo(appid);
	}

}
