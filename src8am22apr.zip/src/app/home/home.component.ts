import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  

  constructor(public router:Router){}
 
  data:any;
  username:string="";
  usertype:string="";
  ngOnInit(): void {
   
    this.data = sessionStorage.getItem("userType");
    this.usertype=JSON.stringify(this.data);
    this.redirectLogin();
  }
  makeLogout() {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
  redirectLogin(){
    if(this.usertype=='"admin"'){
      this.router.navigate(['/admin']);
   } else if(this.usertype=='"user"'){
    this.router.navigate(['/user']);
   }
  }
  loginAs(usertype:string){
    this.usertype=usertype;
    sessionStorage.setItem('userType',usertype);
    if(usertype=="admin")  
    sessionStorage.setItem('userName',"Poornima"); 
    if(usertype=="user")  
    sessionStorage.setItem('userName','Vishhal')  ;
    this.redirectLogin();
  }
}
