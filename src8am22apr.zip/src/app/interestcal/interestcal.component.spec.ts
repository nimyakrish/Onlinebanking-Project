import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterestcalComponent } from './interestcal.component';

describe('InterestcalComponent', () => {
  let component: InterestcalComponent;
  let fixture: ComponentFixture<InterestcalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterestcalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InterestcalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
