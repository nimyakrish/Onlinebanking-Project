import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AccountComponent } from './account/account.component';
import { ApplicantNewComponent } from './applicant-new/applicant-new.component';

import { ApploginComponent } from './applogin/applogin.component';

import { FAQComponent } from './faq/faq.component';
import { HomeComponent } from './home/home.component';
import { InterestcalComponent } from './interestcal/interestcal.component';
import { UserMainComponent } from './user-main/user-main.component';

const routes: Routes = [
  { path:'', component:HomeComponent},
{ path:'faq', component:FAQComponent},
{path:'interest', component:InterestcalComponent},
{path:'aboutus', component:AboutusComponent},
{path:'login',component:ApploginComponent},
{path:'app',component:ApplicantNewComponent},
{path:'acc',component:AccountComponent},
{ path:'user', component:UserMainComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
