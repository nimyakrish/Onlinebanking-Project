export class Applicant{
    applicantid:number=0;
    applicantName:string="abc";
    mobileNumb:string="9";
    applicantFatherName:string="pqr";
    applicantMotherName:string="xyz";
    married:string="marr";
    aadhar:string="f56";
    panCard:string="g78";
    photo:string="h.jpg";
    applicant_status:string="hi";
    account_type:string="hi";    
}
