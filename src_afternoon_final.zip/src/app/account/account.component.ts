import { Component, OnInit } from '@angular/core';
import { AccountService } from '../account.service';
import { Account } from './Account';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
  applarray:Account[]=[];
  appl:Account=new Account();
  constructor(private aps:AccountService) { }

  ngOnInit(): void {
  }

  showall()
  {console.log("in show all")
    this.aps.fetchall().subscribe(
  (data:Account[])=>
  {this.applarray=data;}
  
    );
  }


}
