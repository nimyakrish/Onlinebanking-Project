package com.sbi.project.layer3;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Login;

@CrossOrigin(origins = "http://localhost:4200")
@Repository
public interface LoginRepository  {
	Applicant findLogin(String userName,String password);
	
}
