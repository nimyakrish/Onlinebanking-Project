package com.sbi.project.layer5;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer2.Login;
import com.sbi.project.layer2.SpendAnalysis;
import com.sbi.project.layer4.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/applicants")
public class ApplicantController {

	@Autowired
	ApplicationService appser;
	@Autowired
	TransactionService txnserv;

	public ApplicantController() {
		// TODO Auto-generated constructor stub
	
		System.out.println("Applicant controller");
			
	}
	
	
	
	@RequestMapping("/")
	public List<Applicant> getEmps()
	{
		
			return appser.getAllApplicants();
		
	}

	
	@RequestMapping("/get/{applicantid}")
	public Applicant getApp(@PathVariable("applicantid")  int  esearch )
	{
		Applicant al=appser.getAppliService(esearch);
		return al;	
			
	}//method
	
	@RequestMapping("/auth")	
	public Applicant authenticateCon(@RequestBody Login eadd) {	
	
		Applicant appobj= new Applicant();
		try {
		appobj = appser.authenticate(eadd.getUserName(), eadd.getPassword());
		}catch (Exception e) {
			// TODO: handle exception
			return null;
		}
			
		return appobj;
	}
	
	@RequestMapping("/add")
	public String addApp(@RequestBody Applicant eadd )
	{List<Applicant> al=appser.getAllApplicants();
	
		boolean found=false;
		
		Applicant eobj=null;
		
		
		
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			
			if(eobj.getApplicantid()==eadd.getApplicantid())
			{found=true;
			break;
			}
			
			
		}
			if(found==true)
			return "object already found"+eadd;
		else
		{appser.createApplicationService(eobj)	;
		return "object added "+eadd;
		}	
			
	}//method
	
	@RequestMapping("/upd")
	public String updEmployee(@RequestBody Applicant emodify )
	{
		List<Applicant> al=appser.getAllApplicants();
		
		boolean found=false;
		int x;
		Applicant eobj=null;
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			 x=eobj.getApplicantid();
			
			if(eobj.getApplicantid()==emodify.getApplicantid())
			{found=true;
			appser.removeAppliService(i);
			appser.createApplicationService(eobj);
			break;
			}
		}
			if(found==true)
			return "object modified"+emodify;
		else
		return "object not found "+emodify;
			
			
	}//method
	
	@RequestMapping("/del/{applicantid}")
	public void delApp(@PathVariable("applicantid")  int  esearch )
	{List<Applicant> al=appser.getAllApplicants();
		boolean found=false;
		
		Applicant eobj=null;
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			
			if(eobj.getApplicantid()==esearch)
			{found=true;
			break;
			}
		}
			if(found==true)
			appser.removeAppliService(esearch);
				
		
					
			
	}//method
	
	@RequestMapping("/spend/{applicantid}")
	public SpendAnalysis getSpendApp(@PathVariable("applicantid")  int  esearch ) throws ParseException
	{
		LocalDate now = LocalDate.now();
		int year = now.getYear();
		int month = now.getMonthValue()-1;
		String searchDate="";
		if(month<10)
		 searchDate = year+"-0"+month;
		else 
			 searchDate = year+"-"+month;

		
//		LocalDate localDate = LocalDate.parse("2019-05-08");
//		DateFormat dtf = DateFormat.ofPattern("yyyy-mm");
//		String date = dtf.format(localDate);
//		System.out.println(date); //May 08, 2019 
//		
		SpendAnalysis al=txnserv.getSpendAnalysisService(searchDate,esearch);
		return al;	
			
	}
	
	
	
	
	
}
