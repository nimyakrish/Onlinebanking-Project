package com.sbi.project.layer4;

import java.util.List;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;

public interface AccountService {

	public void createAccSer(Account a);
	public List<Account> getAll();
	public void getAcc(int no);
	public void updAccSer(Account a);
	public void rem(int no);
	public List<Account> getAccOfApplicant(int appId);
	
	
}
