package com.sbi.project.layer3;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Payee;
import com.sbi.project.layer2.SpendAnalysis;
import com.sbi.project.layer2.Transaction;
@Repository
public class TransactionRepositoryImpl extends BaseRepositoryImpl implements TransactionRepository {
		
	@Transactional
	public void addTransaction(Transaction txn) {
		super.persist(txn);
		// TODO Auto-generated method stub
		
	}
	@Override
	public Transaction findTrans(int txnId) {
		// TODO Auto-generated method stub
		return super.find(Transaction.class, txnId);
	}
	@Override
	public List<Transaction> findAllTxns() {
		// TODO Auto-generated method stub
		return super.findAll("Transaction");
	}
	public List<Transaction> getAllTxnsofAccRepo(int accNo){
		
		TypedQuery<Transaction> query = entityManager.createQuery("from Transaction p where "
				+ "p.txnFromAcc.accountNumber=:x ORDER BY p.txnDate  DESC", Transaction.class).setMaxResults(10);
		query.setParameter("x", accNo);
		
		
		List<Transaction> payee = query.getResultList();
		// TODO Auto-generated method stub
		return payee;
		
	}
	
	public SpendAnalysis getSpendAnalysis(String monthYear,int appid) {		

		TypedQuery<Account> query = entityManager.createQuery("from Account a where "
				+ "a.applicant.applicantid=:x ", Account.class);
		query.setParameter("x", appid);
		List<Account> accounts = query.getResultList();
		List<Transaction> alltxns = new ArrayList<Transaction>();
		SpendAnalysis spend = new SpendAnalysis();
		for(Account acc : accounts) {
			List<Transaction> acctxns = new ArrayList<Transaction>();
			
			TypedQuery<Transaction> query2 = entityManager.createQuery("from Transaction p where "
					+ "p.txnFromAcc.accountNumber=:x AND p.txnDate like :indate ORDER BY p.txnDate  DESC", Transaction.class);
			query2.setParameter("x", acc.getAccountNumber());
			//Date startDate = Date.from(monthYear.toInstant());
		query2.setParameter("indate", "%"+monthYear+"%");
		System.out.println(query2);
			List<Transaction> acctxns1 = query2.getResultList();
			float txnAmt=0f;
			for( Transaction txn :acctxns1) {
				alltxns.add(txn);
				txnAmt =txn.getTxnAmt();
				String txnTYpe=txn.getTxnType();
				spend.setTotalTxnAmt(spend.getTotalTxnAmt()+txnAmt);
				if(txnTYpe.equals("Withdrawal")) {
					spend.setTotWithdraw(spend.getTotWithdraw()+txnAmt);
				}else if (txnTYpe.equals("Transfer")) {
					spend.setTotTransfer(spend.getTotTransfer()+txnAmt);
				}else if(txnTYpe.equals("Deposit")) {
					spend.setTotCredit(spend.getTotCredit()+txnAmt);
				}else if(txnTYpe.equals("Savings")) {
					spend.setTotFDCredit(spend.getTotFDCredit()+txnAmt);					
				} else {
					spend.setTotFDCredit(spend.getTotFDCredit()+txnAmt);
				}
				
			}
			
			
			
		}
		return spend;
		
		
		
	}
}
