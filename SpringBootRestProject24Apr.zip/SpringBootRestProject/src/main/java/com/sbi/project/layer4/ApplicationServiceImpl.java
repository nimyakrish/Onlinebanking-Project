package com.sbi.project.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer3.ApplicantRepository;
import com.sbi.project.layer3.ApplicantRepositoryImpl;
import com.sbi.project.layer3.LoginRepository;

@Service
public class ApplicationServiceImpl implements ApplicationService {
	@Autowired
	ApplicantRepository appRepo;
	String message=null;
	
	@Autowired
	LoginRepository logRepo;
	
	
	public Applicant authenticate(String userName,String password) {
		return logRepo.findLogin(userName, password);
	}
	@Override
	public String createApplicationService(Applicant app) {
		//app.setApplicantId(10);
		System.out.println(app);
		
		appRepo.createApp(app);	
		return message;
		
	}
	
	public List<Applicant> getAllApplicants() {
		return appRepo.findAllApp();
	}

	@Override
	public String updateAppliService(Applicant app) {
		// TODO Auto-generated method stub
		List<Applicant> addList = (List<Applicant>) appRepo.findApp(app.getApplicantid());		
		if (addList.size() > 0) {		
			appRepo.modifyApp(app);
			message="Modified the applicants data.....";
		} else {
			message ="Applicantion not exists.....";
		}
		return message;
	}

	@Override
	public String removeAppliService(int appid) {
		// TODO Auto-generated method stub
		List<Applicant> addList = (List<Applicant>) appRepo.findApp(appid);		
		if (addList.size() > 0) {		
			appRepo.removeApp(appid);
			message="Removed the applicants data.....";
		} else {
			message ="Applicantion not exists.....";
		}
		return message;
	}

	@Override
	public Applicant getAppliService(int applino) {
		// TODO Auto-generated method stub
		Applicant a = appRepo.findApp(applino);
		
		return a;
	}
}
