import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-tab',
  templateUrl: './side-tab.component.html',
  styleUrls: ['./side-tab.component.css']
})
export class SideTabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
