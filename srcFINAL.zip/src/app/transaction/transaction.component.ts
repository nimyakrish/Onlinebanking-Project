import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TransactionService } from '../transaction.service';
import { Transaction } from './Transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  constructor(private route:ActivatedRoute,private txnObj:TransactionService) { 
    this.route.params.subscribe( params => this.accNo = params['accNo']);
  }

  accNo:number =0;
  txnArray :Transaction[]=new Array();
  
  ngOnInit(): void {
    this.showTenTxn();
  }
    showTenTxn(){
        console.log("in show all")
        this.txnObj.fetchallTentxn(this.accNo).subscribe(
      (data:Transaction[])=>
      {this.txnArray=data;}
      
        );
      }
   
    
  

  
}
