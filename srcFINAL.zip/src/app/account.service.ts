import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Account } from './account/Account';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private myhttp:HttpClient,private auth:AuthenticationService) { }

  appObj:any;
  fetchall():Observable<Account[]>
  {
    this.appObj = this.auth.getLogedApplicant();
    return this.myhttp.get<Account[]>("http://localhost:8080/accounts/get/"+this.appObj.applicantid);
  
  }

}
