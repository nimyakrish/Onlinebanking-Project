import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Applicant } from './applicant-new/Applicant';
import { AuthenticationService } from './authentication.service';
import { SpendAnalysis } from './spend-analysis/SpendAnalysis';

@Injectable({
  providedIn: 'root'
})
export class SpendAnalysisService {

  

appl:Applicant=new Applicant();
constructor(private myhttp:HttpClient,private aps:AuthenticationService) {
   this.appl= this.aps.getLogedApplicant();
 }

appObj:any;
fetchSpendAnalysis():Observable<SpendAnalysis>
{
this.appObj=this.aps.getLogedApplicant();
  console.log( this.myhttp.get<SpendAnalysis>("http://localhost:8080/applicants/spend/113"));
return  this.myhttp.get<SpendAnalysis>("http://localhost:8080/applicants/spend/"+this.appObj.applicantid);
}
}