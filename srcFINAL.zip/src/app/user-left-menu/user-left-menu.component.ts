import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-user-left-menu',
  templateUrl: './user-left-menu.component.html',
  styleUrls: ['./user-left-menu.component.css']
})
export class UserLeftMenuComponent implements OnInit {

  image:any;
  constructor(private authObj:AuthenticationService) {

    this.image=sessionStorage.getItem('userPhoto')?.toLowerCase();
   }

  ngOnInit(): void {
  }

  
  logout(){
    this.authObj.makeLogout();
  }

}
