import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
  styleUrls: ['./faq.component.css']
})
export class FAQComponent implements OnInit {
  appObj :any;
  stylecss :string="noUserDiv";
  constructor(private auth: AuthenticationService) {
    this.appObj= this.auth.getLogedApplicant();
    if(this.appObj){
      this.stylecss ="userDiv";
    }

   }
 

  ngOnInit(): void {
  }

}
