import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Applicant } from './applicant-new/Applicant';
import { ApplicantService } from './applicant.service';
import { AuthenticationService } from './authentication.service';
import { Payee } from './payee/Payee';

@Injectable({
  providedIn: 'root'
})
export class PayeeService {

  appl:Applicant=new Applicant();
  constructor(private myhttp:HttpClient,private aps:AuthenticationService) {
     this.appl= this.aps.getLogedApplicant();
   }

   appObj:any;

  fetchall():Observable<Payee[]>
  {
    this.appObj = this.aps.getLogedApplicant();
    return this.myhttp.get<Payee[]>("http://localhost:8080/payees/get/"+this.appObj.applicantid);
  
  }


}