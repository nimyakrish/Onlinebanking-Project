import java.time.LocalDate;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import entity.Employee;
import entity.Employee;
import entity.Project;
import entity.Project;

public class ManyToManyEmployeeProject {
	EntityManagerFactory emf;
	EntityManager em ;
	
	public ManyToManyEmployeeProject() {
		
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();
		
	}
	@Test
	public void createProjects() {
		Project newproj1 = new Project();
		newproj1.setProjectTitle("SCORE Project");
		newproj1.setProjectDeadLine(LocalDate.of(2030, 10, 20));
		
		Project newproj2 = new Project();
		newproj2.setProjectTitle("Online Project");
		newproj2.setProjectDeadLine(LocalDate.of(2030, 1, 2));
		
		Project newproj3 = new Project();
		newproj3.setProjectTitle("Airline Project");
		newproj3.setProjectDeadLine(LocalDate.of(2030,2, 22));
		
		
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(newproj1);
			em.persist(newproj2);
			em.persist(newproj3);
		et.commit();	
	}
	
		
	
	@Test
	public void asssignProjectToExEmp() {
		Employee emp = em.find(Employee.class, 3);
		
		Project proj1 = em.find(Project.class, 4);
		Project proj2 = em.find(Project.class, 5);
		Project proj3= em.find(Project.class, 6);
		
		emp.getProjectList().add(proj1);
		emp.getProjectList().add(proj2);
		emp.getProjectList().add(proj3);
		
		EntityTransaction et = em.getTransaction();
		
		et.begin();
			em.merge(emp);
		et.commit();
		
	}
	
	@Test
	public void getProjectOfEmployee() {
		
		Employee emp = em.find(Employee.class, 3);
		
		Set<Project> projList = emp.getProjectList();
		System.out.println(emp.getName()+" project List");
		System.out.println("==============================");
		for(Project currproj : projList ) {
			System.out.println("Name	: "+currproj.getProjectTitle());
		}
		System.out.println("==============================");
		
	}
	
	
	
}
