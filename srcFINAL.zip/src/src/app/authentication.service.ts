import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(public router:Router) { }
  usertype:string='';
  username:string='';
  data:any;

  makeLogout() {
    sessionStorage.clear();
    //this.router.navigate(['home/logout']);
    //window.location.reload();
    this.router.navigate(['home'])
  .then(() => {
    window.location.reload();
  });
    
  }
  redirectLogin(){
    
    if(this.usertype=='"admin"'){
      this.router.navigate(['/admin']);
   } else if(this.usertype=='"user"'){
    this.router.navigate(['/user']);
   }
  }
  loginAs(usertype:string){
    this.usertype=usertype;
    sessionStorage.setItem('userType',usertype);
    if(usertype=="admin")  
    sessionStorage.setItem('userName',"Poornima"); 
    if(usertype=="user")  
    sessionStorage.setItem('userName','Vishhal')  ;
    
    this.redirectLogin();
    window.location.reload();
  }
  verifyUser(){
    this.data = sessionStorage.getItem("userType");
    this.usertype=JSON.stringify(this.data);
    this.redirectLogin();
  }
}
