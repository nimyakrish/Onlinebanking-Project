package dao;
import java.util.ArrayList;

import entity.Passport;

public interface PassportDAO {
	public void createPassport(Passport passnew);
	public Passport selectPass(String passId);
	public void updatePass(Passport passupdate);
	public void deletePass(String passId);
	public void selectAllPassports();

}
