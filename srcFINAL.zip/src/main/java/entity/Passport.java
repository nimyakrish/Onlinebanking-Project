package entity;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="pass_tbl")
public class Passport {
	@Id
	@Column(name="pass_id", length = 20)
	private String passportNumber;
	
	@Column(name="pass_issuedate")
	private LocalDate issueDate;
	
	@Column(name="pass_expdate")
	private LocalDate expiryDate;
	
	@Column(name="pass_issuedby")
	private String  issuedBy;
	
	
	@OneToOne
	private Employee emp_id;

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public LocalDate getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(LocalDate issueDate) {
		this.issueDate = issueDate;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public Passport() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(Employee emp_id) {
		this.emp_id = emp_id;
	}
	
	
	
}
