import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  title = 'BankingProject';
  data :any;
  user =false;
  admin=false;
  nouser=false;
  username:string='Roshni';
  usertype:string="";

  ngOnInit(): void {
    //this.user=true;
   
    this.data = sessionStorage.getItem("userType");
    this.usertype=JSON.stringify(this.data);
    this.showMenu();

  }
  
  showMenu(){
    
    if(this.usertype=='"admin"'){
       this.admin=true; 
            
    }else if(this.usertype=='"user"'){
       this.user=true; 
       
    }else{
      
      this.nouser =true;
    }
    
  }
  }
