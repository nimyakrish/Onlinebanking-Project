import { dateFormat } from "highcharts";

export class Applicant{
    
	applicantid:number=0;
	applicantName:string='';
	gender:string ='';
	mobileNumb:number =0;	
	email:string='';	
	applicantFatherName:string ='';
	applicantDob:Date =new Date();
    occupation: string='';
	income:number=0;
	married:string ='';
    aadhar:string='';
    panCard:string='';
	photo:string='';
	applicant_status:string='';
	account_type:string='';	
	account_address:string='';
	



}
