import { TestBed } from '@angular/core/testing';

import { SpendAnalysisService } from './spend-analysis.service';

describe('SpendAnalysisService', () => {
  let service: SpendAnalysisService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SpendAnalysisService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
