import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AccountService } from '../account.service';
import { Account } from '../account/Account';
import { AccountComponent } from '../account/account.component';
import { TransactionService } from '../transaction.service';
import { Transaction } from '../transaction/Transaction';
import { TransactionComponent } from '../transaction/transaction.component';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {
  accNo:number =0;
  txnArray :Transaction[]=new Array();
  constructor(private txnObj:TransactionService,private route:ActivatedRoute,private aps:AccountService) { 
    this.route.params.subscribe( params => this.accNo = params['accNo']);
  }

  ngOnInit(): void {
    this.showall();
  }
applarray:Account[]=[];
  showall()
  {console.log("in show all")
    this.aps.fetchall().subscribe(
  (data:Account[])=>
  {this.applarray=data;
    
  }
  
    );
  }
  selectedaccNo:number=0;
setAcc(){
  
  this.accNo=this. selectedaccNo;
  this.showAllTxn();
}
  showAllTxn(){
    console.log("in show all")
    this.txnObj.fetchAlltxn(this.accNo).subscribe(
  (data:Transaction[])=>
  {this.txnArray=data;}
  
    );
  }
}
