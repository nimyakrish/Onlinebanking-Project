import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Applicant } from './applicant-new/Applicant';
import { AuthenticationService } from './authentication.service';

@Injectable({
  providedIn: 'root'
})
export class ApplicantService {

  constructor(private myhttp:HttpClient,private auth:AuthenticationService) { }
appObj:any;
fetch():Observable<Applicant>
{
  this.appObj =this.auth.getLogedApplicant();
  return this.myhttp.get<Applicant>("http://localhost:8080/applicants/get/"+this.appObj.applicantid);

}

fetchall():Observable<Applicant[]>
{return this.myhttp.get<Applicant[]>("http://localhost:8080/applicants/");

}


}
