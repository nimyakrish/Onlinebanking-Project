package dao;
import java.util.ArrayList;

import entity.Employee;

public interface EmployeeDAO {
	public void createEmp(Employee empnew);
	public Employee selectEmp(int empid);
	public void updateEmp(Employee emp);
	public void deleteEmp(int empid);
	public ArrayList<Employee> selectAllEmployees();

}
