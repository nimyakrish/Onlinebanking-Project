package com.sbi.project;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Payee;
import com.sbi.project.layer2.Transaction;
import com.sbi.project.layer3.AccountRepository;
import com.sbi.project.layer3.PayeeRepository;
import com.sbi.project.layer3.TransactionRepository;


@SpringBootTest
class PracticeSpringBootApplicationTests {
@Autowired
AccountRepository appRepo;

@Autowired
PayeeRepository pa;
@Autowired
TransactionRepository txnR;

	@Test
	void contextLoads() {
		
		
	}

	@Test
	void getAccount()
	{
	
	List<Account> all = appRepo.findAllAccounts();
	System.out.println("all applicant size "+all.size());
//	for (Account acc : all)
//	{
//		System.out.println("Account num        : "+acc.getAccountNumber());
//		System.out.println("name     :  "+acc.getAccountHolderName());
//		System.out.println("balance     :  "+acc.getAccountBalnce());
//		
//	}
	}
	@Test
	void getA()
	{
	
	List<Payee> all = pa.findAllP();
	System.out.println("all applicant size "+all.size());
	for (Payee pa : all)
	{
		System.out.println("payee acc        : "+pa.getPayeeacc());
		System.out.println("id     :  "+pa.getPayeeid());
		System.out.println("ifsc     :  "+pa.getPayeeifsc());
		System.out.println(" name    :  "+pa.getPayeename());
		
		
	}
	
	
	
}

	@Test
	void textfindtxn() {
		List<Transaction> all = txnR.findAllTxns();
		for (Transaction pa : all)
		{
		System.out.println(pa);
		}
	}
}
