package com.sbi.project.layer2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;


@Component 
@Entity 
@Table(name="account_tbl")
public class Account {
	@Id	@GeneratedValue	@Column(name="acc_no")
	private int accountNumber;
	
	@Column(name="acc_bal")
	private int accountBalnce;
	
	@Column(name="acc_open_date")
	private LocalDate accOpenDate;
	
	@ManyToOne
	@JoinColumn(name="app_id")
	Applicant applicant;
	
	
	@OneToMany(mappedBy = "txnFromAcc", cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	List<Transaction> txnList= new ArrayList<Transaction>();

	public List<Transaction> getTxnList() {
		return txnList;
	}

	public void setTxnList(List<Transaction> txnList) {
		this.txnList = txnList;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getAccountBalnce() {
		return accountBalnce;
	}

	public void setAccountBalnce(int accountBalnce) {
		this.accountBalnce = accountBalnce;
	}

	public LocalDate getAccOpenDate() {
		return accOpenDate;
	}

	public void setAccOpenDate(LocalDate accOpenDate) {
		this.accOpenDate = accOpenDate;
	}

	public Applicant getApplicant() {
		return applicant;
	}

	public void setApplicant(Applicant applicant) {
		this.applicant = applicant;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountBalnce=" + accountBalnce + ", accOpenDate="
				+ accOpenDate + ", applicant=" + applicant + "]";
	}
	
	
	
	
	
}
