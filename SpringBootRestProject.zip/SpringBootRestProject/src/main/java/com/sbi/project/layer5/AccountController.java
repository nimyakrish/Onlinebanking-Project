package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.AccountService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/accounts")

public class AccountController {


	@Autowired
	AccountService appser;

	@RequestMapping("/")
	public List<Account> getEmps()
	{
		
			return appser.getAll();
		
	}
	
	@RequestMapping("/get/{accno}") 
	public List<Account> getAccounts(@PathVariable("accno") int appNoToSearch) {
		System.out.println("/getAccounts");
		return appser.getAccOfApplicant(appNoToSearch);
	}
	
}
