package com.sbi.project.layer3;

import java.util.List;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.project.layer2.Account;
@Repository
public class AccountRepositoryImpl extends BaseRepositoryImpl implements AccountRepository {
	
	@Transactional
	public void createAccount(Account account) {
		super.persist(account);
	}
	@Transactional
	public void modifyAccount(Account account) {
		super.merge(account);
	}
	@Transactional
	public void removeAccount(int acno) {
		Account accObj = super.find(Account.class, acno);
		super.remove(accObj);
	}

	public Account findAccount(int acno) {
		return super.find(Account.class, acno);
	}

	public List<Account> findAllAccounts() {
		return super.findAll("Account");
	}
	@Override
	public List<Account> findAllAccountfromAppId(int param) {
		// TODO Auto-generated method stub
		TypedQuery<Account> typedQuery=entityManager.createQuery("from account_tbl where app_id=:x",Account.class);
		typedQuery.setParameter("x",param);
		return typedQuery.getResultList();
	}
}
