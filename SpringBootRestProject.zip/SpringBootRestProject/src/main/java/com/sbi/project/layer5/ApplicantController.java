package com.sbi.project.layer5;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.sbi.project.layer2.Applicant;
import com.sbi.project.layer4.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/applicants")
public class ApplicantController {

	@Autowired
	ApplicationService appser;

	
	

	
	

public ApplicantController() {
		// TODO Auto-generated constructor stub
	
		System.out.println("Applicant controller");
			
	}
	
	
	
	@RequestMapping("/")
	public List<Applicant> getEmps()
	{
		
			return appser.getAll();
		
	}

	
	@RequestMapping("/get/{applicantid}")
	public Applicant getApp(@PathVariable("applicantid")  int  esearch )
	{List<Applicant> al=appser.getAll();
		boolean found=false;
		
		Applicant eobj=null;
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			
			if(eobj.getApplicantid()==esearch)
			{found=true;
			break;
			}
		}
			if(found==true)
			return eobj;
		else
			return null;
			
			
	}//method
	
	
	@RequestMapping("/add")
	public String addApp(@RequestBody Applicant eadd )
	{List<Applicant> al=appser.getAll();
	
		boolean found=false;
		
		Applicant eobj=null;
		
		
		
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			
			if(eobj.getApplicantid()==eadd.getApplicantid())
			{found=true;
			break;
			}
			
			
		}
			if(found==true)
			return "object already found"+eadd;
		else
		{appser.createAppSer(eadd);	
		return "object added "+eadd;
		}	
			
	}//method
	
	@RequestMapping("/upd")
	public String updEmployee(@RequestBody Applicant emodify )
	{
		List<Applicant> al=appser.getAll();
		
		boolean found=false;
		int x;
		Applicant eobj=null;
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			 x=eobj.getApplicantid();
			
			if(eobj.getApplicantid()==emodify.getApplicantid())
			{found=true;
			appser.rem(x);
			appser.createAppSer(emodify);
			break;
			}
		}
			if(found==true)
			return "object modified"+emodify;
		else
		return "object not found "+emodify;
			
			
	}//method
	
	@RequestMapping("/del/{applicantid}")
	public void delApp(@PathVariable("applicantid")  int  esearch )
	{List<Applicant> al=appser.getAll();
		boolean found=false;
		
		Applicant eobj=null;
		
		for(int i=0;i<al.size();i++)
		{
			eobj=al.get(i);
			System.out.println(eobj);
			
			if(eobj.getApplicantid()==esearch)
			{found=true;
			break;
			}
		}
			if(found==true)
			appser.rem(esearch);
				
		
					
			
	}//method
	
	
	
	
	
	
	
}
