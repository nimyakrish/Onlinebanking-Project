package com.sbi.project.layer2;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Component
@Entity
@Table(name="txn_tbl")
public class Transaction {
	@Id
	@GeneratedValue
	@Column(name="txn_id")
	private int txnId;
	
	@Column(name="txn_date")
	private LocalDate txnDate;
	
	@Column(name="txn_amt")
	private float txnAmt;	
	
	@ManyToOne
	@JoinColumn(name="txn_from_acc")
	private Account txnFromAcc;
	
	@Column(name="txn_type")
	private String txnType;
	
	
	@Column(name="txn_to_acc")
	private Integer txnToAcc=0;
	
	@Column(name="txn_det")
	private String txnDetails;
	
	@Column(name="txn_bal_src")
	private float currBalSrc;
	
	public int getTxnId() {
		return txnId;
	}

	public void setTxnId(int txnId) {
		this.txnId = txnId;
	}

	public LocalDate getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(LocalDate txnDate) {
		this.txnDate = txnDate;
	}

	public float getTxnAmt() {
		return txnAmt;
	}

	public void setTxnAmt(float txnAmt) {
		this.txnAmt = txnAmt;
	}

	

	public Account getTxnFromAcc() {
		return txnFromAcc;
	}

	public void setTxnFromAcc(Account txnFromAcc) {
		this.txnFromAcc = txnFromAcc;
	}

	public float getCurrBalSrc() {
		return currBalSrc;
	}

	public void setCurrBalSrc(float currBalSrc) {
		this.currBalSrc = currBalSrc;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public int getTxnToAcc() {
		return txnToAcc;
	}

	public void setTxnToAcc(int txnToAcc) {
		this.txnToAcc = txnToAcc;
	}

	public String getTxnDetails() {
		return txnDetails;
	}

	public void setTxnDetails(String txnDetails) {
		this.txnDetails = txnDetails;
	}

	@Override
	public String toString() {
		return "Transaction [txnId=" + txnId + ", txnDate=" + txnDate + ", txnAmt=" + txnAmt + ", txnFromAcc="
				+ txnFromAcc + ", txnType=" + txnType + ", txnToAcc=" + txnToAcc + ", txnDetails=" + txnDetails + "]";
	}
	
	
	
	

}
