package com.sbi.project.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sbi.project.layer2.Payee;
import com.sbi.project.layer4.PayeeService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/payees")
public class PayeeController {


	@Autowired
	PayeeService paser;
	
	@RequestMapping("/")
	public List<Payee> getEmps()
	{		
			return paser.findAllP();
		
	}
	
	
	
	
}
