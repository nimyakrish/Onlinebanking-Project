package com.sbi.project.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.sbi.project.layer2.Account;
import com.sbi.project.layer2.Transaction;
@Repository
public class TransactionRepositoryImpl extends BaseRepositoryImpl implements TransactionRepository {
		
	@Transactional
	public void addTransaction(Transaction txn) {
		super.persist(txn);
		// TODO Auto-generated method stub
		
	}
	@Override
	public Transaction findTrans(int txnId) {
		// TODO Auto-generated method stub
		return super.find(Transaction.class, txnId);
	}
	@Override
	public List<Transaction> findAllTxns() {
		// TODO Auto-generated method stub
		return super.findAll("Transaction");
	}
}
