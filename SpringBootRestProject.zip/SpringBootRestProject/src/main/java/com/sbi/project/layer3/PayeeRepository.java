package com.sbi.project.layer3;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.sbi.project.layer2.Payee;

@Repository
public interface PayeeRepository {


		void createP(Payee pa);
		void modifyP(Payee pa);
		void removeP(int pa);
		Payee findP(int pa);
		List<Payee> findAllP();
	
}
