import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Transaction } from './transaction/Transaction';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private myhttp:HttpClient) { }


  fetchallTentxn(accNo:number):Observable<Transaction[]>
  {return this.myhttp.get<Transaction[]>("http://localhost:8080/txns/getAll/"+accNo);
  
  }
}
