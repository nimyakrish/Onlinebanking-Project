import { HttpClient, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Applicant } from './applicant-new/Applicant';
import { ApplicantService } from './applicant.service';
import { Login } from './applogin/Login';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  
  constructor(public router:Router,private aps:ApplicantService,private myhttp:HttpClient) { 

    this.aps.fetch().subscribe(
      (data:Applicant)=>
      {this.appl=data;
      
      }
      );
  }
  usertype:string='';
  username:string='';
  data:any;
  appl:Applicant=new Applicant();

  makeLogout() {
    sessionStorage.clear();
    //this.router.navigate(['home/logout']);
    //window.location.reload();
    this.router.navigate(['home'])
  .then(() => {
    window.location.reload();
  });
    
  }
  redirectLogin(){
    
    if(this.usertype=='"admin"'){
      this.router.navigate(['/admin']);
   } else if(this.usertype=='"user"'){
    this.router.navigate(['/user']);
   }
  }

  appUser:Applicant = new Applicant();
  log: Login =new Login();
  authenticate(username:string,password:string):Observable<Applicant>
  {
    this.log.userName =username;
    this.log.password=password;

    const headers = { 'content-type': 'application/json'}  
    const body=JSON.stringify(this.log);
    console.log(this.log)
    return this.myhttp.post<Applicant>("http://localhost:8080/applicants/auth/",body,{'headers':headers});
  
    
  }
    
  // loginAs(usertype:string){
  //   this.usertype=usertype;
  //   sessionStorage.setItem('userType',usertype);
  //   if(usertype=="admin")  {
  //     sessionStorage.setItem('userName',"Poornima"); 
  //   }
        
  //   if(usertype=="user")  {

      
  //       console.log(this.appl);

      
  //     sessionStorage.setItem('appId',JSON.stringify(this.appl.applicantid));
  //     sessionStorage.setItem('userName','Vishhal')  ;

  //   }
    
    
  //   this.redirectLogin();
  //  window.location.reload();
  // }
  verifyUser(){
    this.data = sessionStorage.getItem("userType");
    this.usertype=JSON.stringify(this.data);
    this.redirectLogin();
  }

  getLogedApplicant():Applicant{
    
    this.data = sessionStorage.getItem("appObj");
    const appObj=this.data;
    return appObj;

  }
}
