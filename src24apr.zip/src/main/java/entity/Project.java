package entity;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="proj_tbl")
public class Project {
	
	@Id
	@GeneratedValue
	@Column(name="proj_id")
	private int projectId;
	
	@Column(name="proj_title" , length =20)
	private String projectTitle;
	
	@Column(name="proj_dead")
	private LocalDate projectDeadLine;
	
	@ManyToMany(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinTable(name="project_employee_tbl",
	joinColumns = {@JoinColumn(name="projId")},
	inverseJoinColumns= {@JoinColumn(name="empId")})
	private Set<Employee> empList = new HashSet<Employee>();
	
	
	
	
	public Set<Employee> getEmpList() {
		return empList;
	}
	public void setEmpList(Set<Employee> empList) {
		this.empList = empList;
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjectTitle() {
		return projectTitle;
	}
	public void setProjectTitle(String projectTitle) {
		this.projectTitle = projectTitle;
	}
	public LocalDate getProjectDeadLine() {
		return projectDeadLine;
	}
	public void setProjectDeadLine(LocalDate projectDeadLine) {
		this.projectDeadLine = projectDeadLine;
	}

}
