package dao;
import java.util.ArrayList;

import entity.Project;

public interface ProjectDAO {
	public void createProject(Project projnew);
	public Project selectProj(int projId);
	public void updateProj(Project projupdate);
	public void deleteProj(int projId);
	public void selectAllProjects();

}
