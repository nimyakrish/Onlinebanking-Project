package dao;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import entity.Passport;



public class PassportDAOImpl implements PassportDAO{
	
	EntityManagerFactory 	emf;
	EntityManager 			em ;		
	EntityTransaction 		et;
	
	 public PassportDAOImpl() {
		this.emf 	= Persistence.createEntityManagerFactory("MyJPA");
		this.em 	= emf.createEntityManager();		
		this.et 	= em.getTransaction();
			
	}
	public void createPassport(Passport newpass) {		
		et.begin();
		 em.persist(newpass);
		et.commit();		
		
	}

	public Passport selectPass(String passId) {
		
		Passport selPass = em.find(Passport.class, passId); //2 is primary key 
		try {
				System.out.println(" Passport No		:"+selPass.getPassportNumber());
				System.out.println(" Expirt Date		:"+selPass.getExpiryDate());
				System.out.println(" Issue Date			:"+selPass.getIssueDate());
				System.out.println(" Issed By			:"+selPass.getIssuedBy());
					
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		return selPass;
	}

	public void updatePass(Passport newpass) {
		
		et.begin();
		 em.merge(newpass);
		et.commit();
		
	}

	public void deletePass(String passId) {
		Passport selPass = em.find(Passport.class, passId); //2 is primary key 
		try {			
			System.out.println(" Passport No		:"+selPass.getPassportNumber());
			System.out.println(" Expirt Date		:"+selPass.getExpiryDate());
			System.out.println(" Issue Date			:"+selPass.getIssueDate());
			System.out.println(" Issed By			:"+selPass.getIssuedBy());
			
			et.begin();
				em.remove(selPass);
			et.commit();
			
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		
		
		
	}

	public void selectAllPassports() {
		Query query 			= em.createQuery("from Passport");
		List<Passport> passList	= query.getResultList();
		if(passList.size()>0) {
			for(Passport   currPass : passList){
				System.out.println(" Passport No		:"+currPass.getPassportNumber());
				System.out.println(" Expirt Date		:"+currPass.getExpiryDate());
				System.out.println(" Issue Date			:"+currPass.getIssueDate());
				System.out.println(" Issed By			:"+currPass.getIssuedBy());
				System.out.println("====================================");
				
			}
		}
		
	}
	

}
