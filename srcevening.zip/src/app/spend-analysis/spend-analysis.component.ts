import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spend-analysis',
  templateUrl: './spend-analysis.component.html',
  styleUrls: ['./spend-analysis.component.css']
})
export class SpendAnalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
