import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Test;

import dao.EmployeeDAOImpl;
import dao.PassportDAOImpl;
import entity.Employee;
import entity.Passport;

public class OneToOnePassportEmployee {
	EmployeeDAOImpl empTest	= new EmployeeDAOImpl();
	PassportDAOImpl passTest	= new PassportDAOImpl();
	
	EntityManagerFactory emf;
	EntityManager em ;
	
	public OneToOnePassportEmployee() {
		
		System.out.println("Trying to read persistence.xml file...");

		// 3
		this.emf = Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("EntityManagerFactory created....");

		this.em = emf.createEntityManager();
		System.out.println("EntityManager created....");
	}
	
	@Test
	public void NewEmployeeWithNewPassport() {
		Employee newemp = new Employee();
		newemp.setName("Nimya");
		newemp.setAge(35);
		newemp.setJob("TO Sys");
		newemp.setJoiningDate(LocalDate.of(2020, 10, 20));
		newemp.setSalary(50000);
		
		
		Passport newpass = new Passport();
		newpass.setPassportNumber("DBC45JN");
		newpass.setIssueDate(LocalDate.of(2020, 8, 10));
		newpass.setExpiryDate(LocalDate.of(2030, 8, 10));
		newpass.setIssuedBy("Govt of India");
		
		newemp.setPass_id(newpass);
		newpass.setEmp_id(newemp);
		EntityTransaction et = em.getTransaction();
		et.begin();
			em.persist(newemp);
			em.persist(newpass);
		et.commit();
		
	}
	@Test
	public void NewEmployeeWithExistingPassport() {
		Employee newemp = new Employee();
		newemp.setName("Riyas");
		newemp.setAge(25);
		newemp.setJob("SO Sys");
		newemp.setJoiningDate(LocalDate.of(2021, 10, 20));
		newemp.setSalary(45000);
		
		EntityTransaction tx = em.getTransaction();
		tx.begin();
			Passport passport = em.find(Passport.class, 6);
			Employee theEmp   = em.find(Employee.class, 5);
		
			passport.setEmp_id(theEmp);
			theEmp.setPassport(passport);
			
			em.merge(passport);
			em.merge(theEmp);
		tx.commit();	
	}
	
	

}
