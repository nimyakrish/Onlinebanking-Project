package dao;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import entity.Employee;



public class EmployeeDAOImpl implements EmployeeDAO{
	
	EntityManagerFactory emf;
	EntityManager em ;		
	EntityTransaction et;
	
	 public EmployeeDAOImpl() {
		this.emf =Persistence.createEntityManagerFactory("MyJPA");
		this.em = emf.createEntityManager();		
		this.et = em.getTransaction();
			
	}
	

	public void createEmp(Employee newemp) {		
		et.begin();
		 em.persist(newemp);
		et.commit();		
		
	}

	public Employee selectEmp(int empid) {
		
		Employee empList = em.find(Employee.class, empid); //2 is primary key 
		try {
			
				System.out.println(" Id       :"+empList.getEmployeeNumber());
				System.out.println(" Name     :"+empList.getName());
				System.out.println(" Age      :"+empList.getAge());
				System.out.println(" Salary   :"+empList.getSalary());
				System.out.println(" Job      :"+empList.getJob());
		
			
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		return empList;
	}

	public void updateEmp(Employee newemp) {
		
		et.begin();
		 em.merge(newemp);
		et.commit();
		
	}

	public void deleteEmp(int empid) {
		Employee empList = em.find(Employee.class, empid); //2 is primary key 
		try {
			
				System.out.println(" Id       :"+empList.getEmployeeNumber());
				System.out.println(" Name     :"+empList.getName());
				System.out.println(" Age      :"+empList.getAge());
				System.out.println(" Salary   :"+empList.getSalary());
				System.out.println(" Job      :"+empList.getJob());
				et.begin();
				em.remove(empList);
				et.commit();
			
		} catch(Exception e) {
			System.out.println("No record Found");
		}
		
		
		
	}

	public ArrayList<Employee> selectAllEmployees() {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
